package name.asleep.item.custom;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;


public class RylanRageItem extends Item {
    public RylanRageItem(Settings settings){
        super(settings);
    }


    public ActionResult use(ItemUsageContext context) {
        PlayerEntity user = context.getPlayer();

        if (user.getWorld().isClient) {
            return ActionResult.PASS;
        }

        user.sendMessage(Text.literal("Nice stuff"), false);

        // Damage the item after using it (durability goes down)
        context.getStack().damage(1, context.getPlayer(),
                playerEntity -> playerEntity.sendToolBreakStatus(playerEntity.getActiveHand()));

        return ActionResult.SUCCESS;
    }
}