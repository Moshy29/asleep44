package name.asleep.item;

import name.asleep.Asleep44;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItemGroups {
    public static final class_1761 SLEEPING_GROUP = class_2378.method_10230(class_7923.field_44687,
            new class_2960(Asleep44.MOD_ID, "moon"),
            FabricItemGroup.builder().method_47321(class_2561.method_43471("itemgroup.moon"))
                    .method_47320(() -> new class_1799(ModItems.MOON)).method_47317((displayContext, entries) -> {

                        entries.method_45421(ModItems.MOON);
                        entries.method_45421(ModItems.LONDON_VINCENT);

                        entries.method_45421(ModItems.HUMMUS);

                        entries.method_45421(ModItems.RYLAN_RAGE);

                        entries.method_45421(class_1802.field_28408);


                    }).method_47324());


    public static void registerItemGroups(){
        Asleep44.LOGGER.info("yada yada registering item groups n whatnot for " + Asleep44.MOD_ID);
    }
}
