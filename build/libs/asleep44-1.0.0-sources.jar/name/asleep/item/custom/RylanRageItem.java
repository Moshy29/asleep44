package name.asleep.item.custom;

import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_2561;


public class RylanRageItem extends class_1792 {
    public RylanRageItem(class_1793 settings){
        super(settings);
    }


    public class_1269 use(class_1838 context) {
        class_1657 user = context.method_8036();

        if (user.method_37908().field_9236) {
            return class_1269.field_5811;
        }

        user.method_7353(class_2561.method_43470("Nice stuff"), false);

        // Damage the item after using it (durability goes down)
        context.method_8041().method_7956(1, context.method_8036(),
                playerEntity -> playerEntity.method_20236(playerEntity.method_6058()));

        return class_1269.field_5812;
    }
}