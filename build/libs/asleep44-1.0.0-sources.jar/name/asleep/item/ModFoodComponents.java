package name.asleep.item;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_4174;

public class ModFoodComponents {
    public static final class_4174 HUMMUS = new class_4174.class_4175().method_19238(3).method_19237(0.25f)
            .method_19239(new class_1293(class_1294.field_5904, 2000), 1f).method_19242();


}
