package name.asleep.item;

import name.asleep.Asleep44;
import name.asleep.item.custom.RylanRageItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class ModItems {
    public static final class_1792 MOON = registerItem("moon", new class_1792(new FabricItemSettings()));
    public static final class_1792 LONDON_VINCENT = registerItem("london_vincent", new class_1792(new FabricItemSettings()));

    public static final class_1792 HUMMUS = registerItem("hummus", new class_1792(new FabricItemSettings().method_19265(ModFoodComponents.HUMMUS)));

    public static final class_1792 RYLAN_RAGE = registerItem("rylan_rage", new RylanRageItem(
            new FabricItemSettings().method_7895(64)));

    private static void addItemstoIngredientItemGroup(FabricItemGroupEntries entries){
        entries.method_45421(MOON);
        entries.method_45421(LONDON_VINCENT);
    }

    private static class_1792 registerItem(String name, class_1792 item){
        return class_2378.method_10230(class_7923.field_41178, new class_2960(Asleep44.MOD_ID, name), item);
    }

    public static void registerModItems(){
        Asleep44.LOGGER.info("Registering Mod Items for " + Asleep44.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(ModItems::addItemstoIngredientItemGroup);
    }
}
